<?php
/**
 * Created by PhpStorm.
 * User: Geremi
 * Date: 27/11/2019
 * Time: 19:18
 */
namespace App\Controller\Database;

use App\models\Commentaire;
use App\models\User;

class Database{

    static public function selectAllUser($sql,$pdo){
        $stmt = $pdo->query($sql);
        $users = array();
        $i = 0;
        foreach ($stmt as $row) {
            $user = new User();
            $user->setLogin($row['login']);
            $user->setMail($row['mail']);
            $user->setPassword($row['password']);
            $user->setRole($row['roles']);
            $users[$i] = $user;
            $i++;
        }
        return $users;
    }

    static public function selectUserByLonginAndPassword($mail,$password,$pdo){
        $stmt = $pdo->prepare('SELECT * FROM user WHERE mail = ? AND password = ?');
        $stmt->execute(array($mail, $password));
        $user = $stmt->fetch();
        return $user;
    }

    static public function selectUserById($id){
        $pdo = connexionDB();
        $stmt = $pdo->prepare('SELECT * FROM user WHERE id = ?');
        $stmt->execute(array($id));
        $user = $stmt->fetch();
        return $user;
    }

    /*static public function connexionUser($mail,$password,$pdo){
    //Cette fonction permet de faire une authentification de l'utilisateur
         $valid = true;
         $stmt = $pdo->prepare('SELECT * FROM user WHERE login = ? AND password = ?');
         $stmt->execute(array($mail, $password));
         $user = $stmt->fetch();
         if(!$user['mail']){
             $valid = false;
         }
         if($valid){
             //connexion etablit avec succes
             $connecter = new User();
             $connecter->setLogin($user['login']);
             $connecter->setMail($user['mail']);
             $connecter->setPassword($user['password']);
             $connecter->setRole($user['roles']);
         }
         return $connecter;
     }*/


    static public function connexionUser($login,$password,$pdo){
        //Cette fonction permet de faire une authentification de l'utilisateur
        $valid = true;
        $password = md5($password);
        $requete="SELECT * FROM user WHERE login='".$login."' AND password = '".$password."'";
        $resultat=$pdo->query($requete);
        $user = $resultat->fetch();
        if(!$user['mail']){
            $valid = false;

        }
        if($valid){
            //connexion etablit avec succes
            $connecter = new User();
            $connecter->setLogin($user['login']);
            $connecter->setMail($user['mail']);
            $connecter->setPassword($user['password']);
            $connecter->setRole($user['roles']);
        }
        return $connecter;
    }

    static public function selectAllCommentaire($sql,$pdo){
        $commentaires = array();
        $i = 0;
        $stmt = $pdo->query($sql);
        foreach ($stmt as $row) {
            $commentaire = new Commentaire();
            $tit = htmlspecialchars($row['titre'],ENT_QUOTES);
            $com = htmlspecialchars($row['text'],ENT_QUOTES);
            $commentaire->setTitre($tit);
            $commentaire->setContenue($com);
            $commentare = $commentaire->htmlspecialchars_decode();
            $user = self::selectUserById($row['id_user']);
        
            $commentaire->setUser($user);
            $commentaires [$i] = $commentaire;
            $i++;
        }
        return $commentaires;
    }

    static public function newCommentaire($commentaire,$pdo){
        $sql = "INSERT INTO commentaire (titre, text, id_user) VALUES (?,?,?)";
        $stmt= $pdo->prepare($sql);
        $stmt->execute([$commentaire->getTitre(), $commentaire->getContenue(), $commentaire->getUser()['id']]);
    }

    static public function selctCommentaireByUserId(){

    }
}
